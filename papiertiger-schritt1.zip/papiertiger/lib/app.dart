import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

/// Farben im Papiertiger-Look.
class PapiertigerFarben {
  static const tigerOrange = Color(0xFFF28C28);
  static const tinte = Color(0xFF1F1A17);
  static const creme = Color(0xFFFFF8F0);
}

class PapiertigerApp extends StatelessWidget {
  const PapiertigerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Papiertiger',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: PapiertigerFarben.tigerOrange,
        ),
        scaffoldBackgroundColor: PapiertigerFarben.creme,
      ),
      home: const HomeScreen(),
    );
  }
}
