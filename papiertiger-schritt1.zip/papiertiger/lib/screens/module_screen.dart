import 'package:flutter/material.dart';

import '../app.dart';
import '../module.dart';

/// Platzhalter-Seite für ein Modul, bis es gebaut ist.
class ModuleScreen extends StatelessWidget {
  const ModuleScreen({super.key, required this.modul});

  final Modul modul;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: Text(modul.titel)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(modul.icon, size: 72, color: PapiertigerFarben.tigerOrange),
              const SizedBox(height: 16),
              Text(
                modul.beschreibung,
                textAlign: TextAlign.center,
                style: text.titleMedium,
              ),
              const SizedBox(height: 8),
              Text(
                'Dieses Modul wird in Schritt ${modul.bauSchritt} gebaut.',
                textAlign: TextAlign.center,
                style: text.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
