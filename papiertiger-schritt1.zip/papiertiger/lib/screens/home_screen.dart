import 'package:flutter/material.dart';

import '../app.dart';
import '../module.dart';
import 'module_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _oeffne(BuildContext context, Modul modul) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ModuleScreen(modul: modul)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
          children: [
            // Kopf mit Platzhalter für das Tiger-Maskottchen
            Row(
              children: [
                const CircleAvatar(
                  radius: 28,
                  backgroundColor: PapiertigerFarben.tigerOrange,
                  child: Icon(Icons.pets, color: Colors.white, size: 30),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Papiertiger',
                      style: text.headlineMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: PapiertigerFarben.tinte,
                      ),
                    ),
                    Text('Keine Angst vor Post.', style: text.bodyLarge),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Hauptaktion: Brief scannen
            Card(
              color: PapiertigerFarben.tigerOrange,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Neuer Brief?',
                      style: text.titleLarge?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Foto machen, und der Tiger erklärt dir, was drinsteht.',
                      style: text.bodyMedium?.copyWith(color: Colors.white),
                    ),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      key: const ValueKey('brief-scannen'),
                      style: FilledButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: PapiertigerFarben.tinte,
                      ),
                      onPressed: () => _oeffne(context, alleModule.first),
                      icon: const Icon(Icons.photo_camera_outlined),
                      label: const Text('Brief scannen'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            Text('Alle Module', style: text.titleMedium),
            const SizedBox(height: 8),
            for (final modul in alleModule)
              Card(
                key: ValueKey('modul-${modul.nummer}'),
                color: Colors.white,
                child: ListTile(
                  leading: Icon(modul.icon,
                      color: PapiertigerFarben.tigerOrange, size: 28),
                  title: Text(modul.titel),
                  subtitle: Text(modul.beschreibung),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _oeffne(context, modul),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
