import 'package:flutter/material.dart';

/// Ein Modul der App, wie in der Spezifikation beschrieben.
class Modul {
  const Modul({
    required this.nummer,
    required this.titel,
    required this.beschreibung,
    required this.icon,
    required this.bauSchritt,
  });

  final int nummer;
  final String titel;
  final String beschreibung;
  final IconData icon;

  /// In welchem Schritt des Bauplans das Modul gebaut wird.
  final int bauSchritt;
}

const alleModule = <Modul>[
  Modul(
    nummer: 1,
    titel: 'Post verstehen',
    beschreibung: 'Brief fotografieren und in Sekunden verstehen',
    icon: Icons.mail_outline,
    bauSchritt: 3,
  ),
  Modul(
    nummer: 2,
    titel: 'Anträge',
    beschreibung: 'Kindergeld und Wohngeld vorausfüllen',
    icon: Icons.assignment_outlined,
    bauSchritt: 8,
  ),
  Modul(
    nummer: 3,
    titel: 'Verträge und Abos',
    beschreibung: 'Fristen im Blick, Kündigung per Knopfdruck',
    icon: Icons.description_outlined,
    bauSchritt: 5,
  ),
  Modul(
    nummer: 4,
    titel: 'Belege und Garantien',
    beschreibung: 'Kassenbon fotografieren, Garantie nie verpassen',
    icon: Icons.receipt_long_outlined,
    bauSchritt: 4,
  ),
  Modul(
    nummer: 5,
    titel: 'Lebens-Ereignisse',
    beschreibung: 'Checklisten für Umzug, Job, Hochzeit und Baby',
    icon: Icons.checklist,
    bauSchritt: 7,
  ),
  Modul(
    nummer: 6,
    titel: 'Steuer-Vorbereitung',
    beschreibung: 'Belege fürs Finanzamt sammeln',
    icon: Icons.calculate_outlined,
    bauSchritt: 6,
  ),
  Modul(
    nummer: 7,
    titel: 'Was steht mir zu?',
    beschreibung: 'Leistungen finden, die du beantragen kannst',
    icon: Icons.volunteer_activism_outlined,
    bauSchritt: 9,
  ),
];
