// Prüfung für Schritt 1: Jedes der 7 Module ist mit einem Tipp erreichbar.
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:papiertiger/app.dart';
import 'package:papiertiger/module.dart';

void main() {
  testWidgets('Startbildschirm zeigt Titel und alle 7 Module',
      (tester) async {
    await tester.pumpWidget(const PapiertigerApp());

    expect(find.text('Papiertiger'), findsOneWidget);
    expect(alleModule.length, 7);

    for (final modul in alleModule) {
      final karte = find.byKey(ValueKey('modul-${modul.nummer}'));
      await tester.scrollUntilVisible(karte, 100,
          scrollable: find.byType(Scrollable).first);
      expect(karte, findsOneWidget);
    }
  });

  testWidgets('Jedes Modul öffnet seine Seite und führt zurück',
      (tester) async {
    await tester.pumpWidget(const PapiertigerApp());

    for (final modul in alleModule) {
      final karte = find.byKey(ValueKey('modul-${modul.nummer}'));
      await tester.scrollUntilVisible(karte, 100,
          scrollable: find.byType(Scrollable).first);
      await tester.tap(karte);
      await tester.pumpAndSettle();

      expect(find.widgetWithText(AppBar, modul.titel), findsOneWidget);
      expect(find.text('Dieses Modul wird in Schritt ${modul.bauSchritt} gebaut.'),
          findsOneWidget);

      await tester.pageBack();
      await tester.pumpAndSettle();
    }
  });

  testWidgets('Knopf "Brief scannen" öffnet Post verstehen', (tester) async {
    await tester.pumpWidget(const PapiertigerApp());

    await tester.tap(find.byKey(const ValueKey('brief-scannen')));
    await tester.pumpAndSettle();

    expect(find.widgetWithText(AppBar, 'Post verstehen'), findsOneWidget);
  });
}
