# Papiertiger – Schritt 1 starten

Dieses Paket enthält das Grundgerüst: Startbildschirm im Papiertiger-Look und alle 7 Module als Platzhalter.

## Einmalig einrichten (ca. 1 Stunde)

1. **Flutter installieren:** Anleitung für dein System auf https://docs.flutter.dev/get-started/install
   (Windows oder macOS wählen, dann „Android“ als Ziel).
2. **Android Studio installieren** (die Anleitung oben führt dich dorthin). Darin einmal ein
   virtuelles Handy anlegen: *Device Manager → Create Device*.
3. Prüfen: Terminal öffnen (Windows: „PowerShell“, Mac: „Terminal“) und eingeben:
   ```
   flutter doctor
   ```
   Alles mit grünem Haken ist gut. Bei Android muss ein Haken stehen.

## App starten

1. ZIP entpacken, z. B. nach `Dokumente/papiertiger`.
2. Im Terminal in den Ordner wechseln:
   ```
   cd Dokumente/papiertiger
   ```
3. Die fehlenden Android- und iPhone-Dateien erzeugen lassen (vorhandene Dateien bleiben unverändert):
   ```
   flutter create --org de.papiertiger --platforms android,ios .
   ```
4. Pakete laden und App starten (virtuelles Handy vorher in Android Studio starten,
   oder echtes Android-Handy per USB anschließen):
   ```
   flutter pub get
   flutter run
   ```

Für das iPhone brauchst du einen Mac mit Xcode. Unter Windows geht vorerst nur Android.

## Prüfung von Schritt 1

```
flutter test
```

Bestanden, wenn am Ende **All tests passed!** steht. Außerdem von Hand: Die App startet,
und jedes der 7 Module öffnet sich mit einem Tipp und führt mit „Zurück“ wieder zum Start.

Wenn etwas nicht klappt: Kopiere die Fehlermeldung aus dem Terminal in den Chat.
